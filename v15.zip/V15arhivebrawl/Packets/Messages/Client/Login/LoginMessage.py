from Packets.Messages.Server.Login.LoginOkMessage import LoginOkMessage
from Packets.Messages.Server.Home.OwnHomeDataMessage import OwnHomeDataMessage
from Packets.Messages.Server.Alliance.My_Alliance_Message import MyAllianceMessage
from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Packets.Messages.Server.Alliance.AllianceStreamMessage import AllianceStreamMessage
from Packets.Messages.Server.Friend.FriendListMessage import FriendListMessage
from Packets.Messages.Server.UnknownServerPackets import UnknownServerPackets

from Packets.Messages.Server.Login.LoginFailedMessage import LoginFailedMessage
from Utils.Reader import BSMessageReader
from Utils.Helpers import Helpers
from Database.DatabaseManager import DataBase

import json

class LoginMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        
        # Load banned lists from server_config.json
        try:
            with open('server_config.json', 'r') as config_file:
                config = json.load(config_file)
        except Exception as e:
            # Fallback to empty lists if the file is missing or corrupt
            config = {}
        
        self.banned_low_id = config.get("banned_low_id", [])
        self.banned_ip = config.get("banned_ip", [])
    
    def decode(self):
        self.player.high_id = self.read_int()
        self.player.low_id = self.read_int()
        self.player.token = self.read_string()

        self.major = self.read_int()
        self.minor = self.read_int()
        self.build = self.read_int()

        self.fingerprint_sha = self.read_string()

        self.read_int()

        self.OpenUDID = self.read_string()
        self.AndroidID = self.read_string()
        self.OSVersion = self.read_string()

    def process(self):
        # Retrieve client IP; try attribute, fallback to getpeername()
        try:
            client_ip = self.client.address[0]
        except AttributeError:
            client_ip = self.client.getpeername()[0]
        
        # Check update version
        if self.major != 15:
            self.player.err_code = 8
            LoginFailedMessage(
                self.client, self.player, 
                "Update Error! Contact @arhivebrawl on Telegram."
            ).send()
            return

        # Check if low_id is banned
        if self.player.low_id in self.banned_low_id:
            self.player.err_code = 11
            LoginFailedMessage(
                self.client, self.player, 
                "Your ID is banned! For unban, contact @arhivebrawl on Telegram."
            ).send()
            return

        # Check if client IP is banned
        if client_ip in self.banned_ip:
            self.player.err_code = 11
            LoginFailedMessage(
                self.client, self.player, 
                "Your IP is banned! Contact @arhivebrawl for appeal."
            ).send()
            return

        # Maintenance & Patch Check
        if self.player.maintenance:
            LoginFailedMessage(
                self.client, self.player, 
                "Maintenance mode active. Please try again later."
            ).send()
            return

        if self.fingerprint_sha != self.player.patch_sha and self.player.patch:
            LoginFailedMessage(
                self.client, self.player, 
                "Patch mismatch detected!"
            ).send()
            return

        # Custom Message Example (Error Code 1)
        if self.player.err_code == 1:  # Custom Message for Error Code 1
            LoginFailedMessage(
                self.client, self.player, 
                "This is a test custom message!"
            ).send()
            return

        # Normal Login Flow
        if self.player.low_id != 0:
            LoginOkMessage(self.client, self.player).send()
            DataBase.loadAccount(self)  # Load account
            OwnHomeDataMessage(self.client, self.player).send()
            DataBase.loadGameroom(self)

            try:
                MyAllianceMessage(self.client, self.player, self.player.club_low_id).send()
                AllianceStreamMessage(self.client, self.player, self.player.club_low_id, 0).send()
                DataBase.GetmsgCount(self, self.player.club_low_id)
            except Exception as e:
                MyAllianceMessage(self.client, self.player, 0).send()
                AllianceStreamMessage(self.client, self.player, 0, 0).send()

            if self.player.room_id > 0:
                TeamGameroomDataMessage(self.client, self.player).send()
        else:
            # Create a new account if low_id is zero
            self.player.low_id = Helpers.randomID(self)
            self.player.high_id = 0
            self.player.token = Helpers.randomStringDigits(self)

            LoginOkMessage(self.client, self.player).send()
            OwnHomeDataMessage(self.client, self.player).send()