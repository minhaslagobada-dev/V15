from Packets.Messages.Server.Gameroom.TeamGameroomDataMessage import TeamGameroomDataMessage
from Utils.Reader import BSMessageReader
from Utils.Helpers import Helpers

class TeamMemberStatusMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.client = client
        self.player = player

    def decode(self):
        # Read the new status for this player from the incoming bytes
        self.player.status = self.read_Vint()

    def process(self):
        # Find the room matching this player's room_id
        for room in Helpers.rooms:
            if room.get("roomID") == self.player.room_id:
                # Update the status of the matching player in the room list
                for pl in room.get("plrs", []):
                    if pl.get('id') == self.player.low_id:
                        pl['state'] = self.player.status

                # Broadcast updated team data to all players in the room
                for pl in room.get("plrs", []):
                    TeamGameroomDataMessage(self.client, self.player).sendWithLowID(pl['id'])
                break