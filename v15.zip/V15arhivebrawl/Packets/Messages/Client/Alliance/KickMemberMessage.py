from Utils.Reader import BSMessageReader
from Database.DatabaseManager import DataBase
from Packets.Messages.Server.Alliance.Events.KickMemberOK import AllianceKickMemberOK
from Packets.Messages.Server.Alliance.My_Alliance_Message import MyAllianceMessage
from Packets.Messages.Server.Alliance.Alliance_Chat_Server_Message import AllianceChatServerMessage

class Kick_Member_Message(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        _ = self.read_int()           # Packet header / unused
        self.lowID = self.read_int()   # lowID of member to kick
        self.reason = self.read_string()  # optional message reason

    def process(self):
        # Only allow kick if caller is officer or leader
        if self.player.club_role > 0:
            db = DataBase()
            # Fetch the target member record
            member = db.loadMembersById(self.lowID)
            if not member:
                return  # Member not found

            # Remove them from club
            db.replaceOtherValue(self.lowID, "clubID", 0)
            db.replaceOtherValue(self.lowID, "clubRole", 0)
            # Update club roster count and remove from data
            db.AddMember(self.player.club_low_id, self.lowID, member['name'], Action=2)

            # Notify kicker: success
            AllianceKickMemberOK(self.client, self.player).send()
            # Notify all remaining members of roster change
            MyAllianceMessage(self.client, self.player, self.player.club_low_id).send()

            # Broadcast a chat event to all members
            # Event type 4 = member kicked, Tick auto-handled
            db.Addmsg(
                clubID=self.player.club_low_id,
                event=4,
                Low_id=self.player.low_id,
                name=self.player.name,
                role=self.player.club_role,
                msg=f"{member['name']} was kicked: {self.reason or 'no reason'}"
            )
            # Load all current member lowIDs
            db.loadClub(self.player.club_low_id)
            for target_low in db.plrids:
                AllianceChatServerMessage(
                    self.client, self.player,
                    message_type="system",
                    club_low_id=self.player.club_low_id
                ).sendWithLowID(target_low)
