from Packets.Messages.Server.Alliance.Alliance_Chat_Server_Message import AllianceChatServerMessage
from Packets.Messages.Server.Alliance.AllianceStreamMessage import AllianceStreamMessage
from Packets.Messages.Server.OutOfSyncMessage import OutOfSyncMessage
from Packets.Messages.Server.Login.LoginFailedMessage import LoginFailedMessage
from Database.DatabaseManager import DataBase
from Utils.Reader import BSMessageReader

class AllianceChatMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.msg = ""
    
    def decode(self):
        # Read the chat message string.
        self.msg = self.read_string()
        print(f"[DEBUG] Decoded chat message: '{self.msg}' from player {self.player.name}")
        
        # Check if the message is a command. For example, /token.
        if self.msg.lower() == "/token":
            self.isCommand = True
        else:
            self.isCommand = False
    
    def process(self):
        print(f"[DEBUG] Processing chat message from {self.player.name} in club {self.player.club_low_id}")
        
        # If the /token command was issued, send an OutOfSyncMessage with the player's token.
        if self.isCommand:
            LoginFailedMessage(self.client, self.player, f"Your Token: {self.player.token}").send()
            return  # Stop further processing for commands.
        
        # Check if player is in a club
        if self.player.club_low_id == 0:
            print(f"[DEBUG] Player {self.player.name} is not in a club, ignoring message")
            return
        
        # Normal chat message processing:
        # Add the new chat message to the database.
        print(f"[DEBUG] Adding message to database for club {self.player.club_low_id}")
        DataBase.Addmsg(self, self.player.club_low_id, 2, 0,
                        self.player.low_id, self.player.name,
                        self.player.club_role, self.msg)
        
        # DEBUG: Check different ways to access Server clients
        try:
            from main import Server
            print(f"[DEBUG] Server imported successfully")
            print(f"[DEBUG] Server type: {type(Server)}")
            print(f"[DEBUG] Server attributes: {dir(Server)}")
            
            # Try different possible client storage locations
            if hasattr(Server, 'Clients'):
                print(f"[DEBUG] Server.Clients exists: {type(Server.Clients)}")
                print(f"[DEBUG] Server.Clients keys: {list(Server.Clients.keys()) if isinstance(Server.Clients, dict) else 'Not a dict'}")
                
                # Try different possible keys
                possible_keys = ['Clients', 'clients', 'connected_clients', 'connections']
                for key in possible_keys:
                    if key in Server.Clients:
                        clients = Server.Clients[key]
                        print(f"[DEBUG] Found clients in Server.Clients['{key}']: {len(clients) if isinstance(clients, dict) else 'Not a dict'}")
                        
                        # Try to send messages using this client list
                        if isinstance(clients, dict):
                            sent_count = 0
                            for client_socket, client_data in clients.items():
                                try:
                                    print(f"[DEBUG] Checking client: {type(client_data)}")
                                    if hasattr(client_data, 'player'):
                                        print(f"[DEBUG] Client has player: {client_data.player.name if hasattr(client_data.player, 'name') else 'No name'}")
                                        if hasattr(client_data.player, 'club_low_id'):
                                            print(f"[DEBUG] Player club ID: {client_data.player.club_low_id}")
                                            if client_data.player.club_low_id == self.player.club_low_id:
                                                print(f"[DEBUG] Sending message to {client_data.player.name}")
                                                chat_msg = AllianceChatServerMessage(client_socket, client_data.player, self.msg)
                                                chat_msg.send()
                                                sent_count += 1
                                except Exception as e:
                                    print(f"[ERROR] Error processing client: {e}")
                                    import traceback
                                    traceback.print_exc()
                            
                            print(f"[DEBUG] Sent to {sent_count} clients using key '{key}'")
                            if sent_count > 0:
                                return  # Success, no need to try other methods
            
            # Alternative: Try to access clients directly from the current client's connection
            print(f"[DEBUG] Trying alternative approach using current client")
            print(f"[DEBUG] Current client type: {type(self.client)}")
            
            # Sometimes the server instance is accessible through the client
            if hasattr(self.client, 'server'):
                print(f"[DEBUG] Client has server attribute")
                server = self.client.server
                if hasattr(server, 'clients') or hasattr(server, 'connections'):
                    clients = getattr(server, 'clients', None) or getattr(server, 'connections', None)
                    print(f"[DEBUG] Found {len(clients)} connections via client.server")
                    # Process these clients...
            
        except ImportError as e:
            print(f"[ERROR] Failed to import Server: {e}")
        except Exception as e:
            print(f"[ERROR] Error accessing Server: {e}")
            import traceback
            traceback.print_exc()
        
        # Last resort: Just send to the current client (sender) to test if the message works at all
        print(f"[DEBUG] Last resort: sending message back to sender")
        try:
            chat_msg = AllianceChatServerMessage(self.client, self.player, self.msg)
            chat_msg.send()
            print(f"[DEBUG] Message sent to sender successfully")
        except Exception as e:
            print(f"[ERROR] Failed to send message even to sender: {e}")
            import traceback
            traceback.print_exc()