from Database.DatabaseManager import DataBase
from Utils.Reader import BSMessageReader

from Packets.Messages.Server.Friend.FriendListUpdateMessage import FriendListUpdateMessage
from Packets.Messages.Server.Friend.AddFriendFailedMessage import AddFriendFailedMessage  # Added import

class AddFriend(BSMessageReader):

    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.HighID = self.read_int()
        self.LowID = self.read_int()

    def process(self):
        def by_trophy(plr):
            return plr['trophies']
        
        players = DataBase.getAllPlayers(self)
        players.sort(key=by_trophy, reverse=True)
        print(self.HighID, self.LowID)
        
       # это говнокод 

        # Prevent adding the friend by just not doing anything.
        # This avoids the friend list update or any crashes related to it.
        # Simply return without sending any invalid messages.
        
        # Don't send FriendListUpdateMessage and do nothing here.
        # FriendListUpdateMessage(self.client, self.player, self.LowID, players).send()

        AddFriendFailedMessage(
            self.client, self.player, 
            "Friend Logic is not \n Currently not Implemented"
        ).send()

        # You can also return immediately if you want to stop any further logic from executing.
        return