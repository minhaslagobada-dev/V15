from Database.DatabaseManager import DataBase
from Utils.Reader import BSMessageReader
from Packets.Messages.Server.Friend.FriendListUpdateMessage import FriendListUpdateMessage

class AddFriend(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.HighID = self.read_int()
        self.LowID = self.read_int()

    def process(self):
        # Fetch ONLY the target player's data
        db = DataBase()
        db.player = self.player
        target_player = db.getSpecifiedPlayer(self.LowID)
        
        if target_player:
            # Send update ONLY for the target friend
            FriendListUpdateMessage(self.client, self.player, self.LowID, [target_player]).send()
        else:
            print(f"Player with LowID {self.LowID} not found")