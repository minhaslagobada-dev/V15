from Utils.Writer import Writer
from Database.DatabaseManager import DataBase

class FriendListUpdateMessage(Writer):

    def __init__(self, client, player, friendLowID, players):
        super().__init__(client)
        self.id = 20106
        self.player = player
        self.friendID = friendLowID  # Target friend (the one for whom we are sending a friend request)
        self.players = players

    def encode(self):
        self.indexOfPlayer = 1
        self.writeVint(len(self.players))  # Write total number of players

        for player in self.players:
            # Determine the index of the current player
            if player["lowID"] == self.player.low_id:
                self.indexOfPlayer = self.players.index(player) + 1

            self.writeInt(0)  # HighID (unused, so 0)
            self.writeInt(player["lowID"])  # LowID

            self.writeString(player['name'])
            self.writeString()  # Unknown field (empty string)
            self.writeString()  # Unknown field (empty string)
            self.writeString()  # Unknown field (empty string)

            # Write the player's actual trophy count (instead of a constant)
            self.writeInt(player['trophies'])

            # Set the friend state:
            # For the target friend (the one we're trying to add) we set state "2" (friend request sent)
            # For any other player already in the friend list, we set state "4" (friend list)
            friend_state = 2 if player["lowID"] == self.friendID else 4
            self.writeInt(friend_state)

            self.writeInt(0)
            self.writeInt(0)
            self.writeInt(0)
            self.writeInt(0)

            # Write club info if applicable
            if player["clubID"] != 0:
                DataBase.loadClub(self, player["clubID"])
                self.writeBoolean(True)  # Player is in a club
                self.writeInt(0)
                self.writeInt(0)
                self.writeInt(0)
                self.writeString(self.clubName)
                self.writeInt(0)
                self.writeInt(0)
            else:
                self.writeBoolean(False)  # No club

            self.writeString()  # Unknown field (empty string)
            self.writeInt(28000000 + player["profileIcon"])
            self.writeInt(0)
