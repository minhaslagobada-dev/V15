from Utils.Writer import Writer
from Database.DatabaseManager import DataBase

class FriendListUpdateMessage(Writer):
    def __init__(self, client, player, friendLowID, players):
        super().__init__(client)
        self.id = 20106
        self.player = player
        self.friendID = friendLowID
        self.players = players  # Now expects a list with ONLY the target player

    def encode(self):
        self.writeVint(len(self.players))  # Will be 1
        
        for player in self.players:
            self.writeInt(0)  # HighID
            self.writeInt(player["lowID"])  # LowID
            self.writeString(player['name'])
            self.writeString()  # Empty
            self.writeString()  # Empty
            self.writeString()  # Empty
            self.writeInt(player['trophies'])
            
            # Set state to 2 (request sent) for the target
            friend_state = 2 if player["lowID"] == self.friendID else 4
            self.writeInt(friend_state)
            
            self.writeInt(0)
            self.writeInt(0)
            self.writeInt(0)
            self.writeInt(0)
            
            if player["clubID"] != 0:
                DataBase.loadClub(self, player["clubID"])
                self.writeBoolean(True)
                self.writeString(self.clubName)
            else:
                self.writeBoolean(False)
                
            self.writeString()
            self.writeInt(28000000 + player["profileIcon"])
            self.writeInt(0)