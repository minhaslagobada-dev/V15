from Utils.Writer import Writer
from tinydb import TinyDB, Query
from Database.DatabaseManager import DataBase

class AllianceChatServerMessage(Writer):
    def __init__(self, client, player, msg_content):
        super().__init__(client)
        self.msg_content = msg_content
        self.id = 24312
        self.player = player
        print(f"[DEBUG] Creating AllianceChatServerMessage for player {player.name} in club {player.club_low_id}")
    
    def encode(self):
        print(f"[DEBUG] Encoding AllianceChatServerMessage for club {self.player.club_low_id}")
        
        # Get the latest message count first
        DataBase.GetmsgCount(self, self.player.club_low_id)
        print(f"[DEBUG] Message count: {self.MessageCount}")
        
        db = TinyDB('Database/Club/chat.db')
        query = Query()
        data_list = db.search(query.clubID == self.player.club_low_id)
        
        if not data_list:
            print(f"[ERROR] No chat data found for club {self.player.club_low_id}")
            return
        
        data = data_list[0]
        
        # Get the latest message (the one that was just added)
        latest_msg_index = str(self.MessageCount)
        msg_info = data['info'].get(latest_msg_index)
        
        if not msg_info:
            print(f"[ERROR] No message found at index {latest_msg_index}")
            print(f"[DEBUG] Available message indices: {list(data['info'].keys())}")
            return
        
        print(f"[DEBUG] Found message: {msg_info}")
        
        # Encode the message data
        self.writeVint(msg_info['Event'])        # Event type (2 for chat message)
        self.writeVint(0)                        # Unknown
        self.writeVint(msg_info['Tick'])         # Message tick
        self.writeVint(0)                        # Unknown
        self.writeVint(msg_info['PlayerID'])     # Player ID who sent the message
        self.writeString(msg_info['PlayerName']) # Player name
        self.writeVint(msg_info['PlayerRole'])   # Player role in club
        self.writeVint(0)                        # Unknown
        self.writeVint(0)                        # Unknown
        
        if msg_info['Event'] == 4:  # Leave club event
            self.writeVint(msg_info['Message'])
            self.writeVint(1)
            self.writeVint(0)
            self.writeVint(msg_info['PlayerID'])
            self.writeString(msg_info['PlayerName'])
            print(f"[DEBUG] Encoded leave club message")
        else:  # Regular chat message
            self.writeString(msg_info['Message'])  # The actual message content
            print(f"[DEBUG] Encoded chat message: '{msg_info['Message']}'")
        
        print(f"[DEBUG] AllianceChatServerMessage encoding complete")
    
    def send(self):
        print(f"[DEBUG] Sending AllianceChatServerMessage (ID: {self.id}) to client")
        super().send()
        print(f"[DEBUG] AllianceChatServerMessage sent successfully")