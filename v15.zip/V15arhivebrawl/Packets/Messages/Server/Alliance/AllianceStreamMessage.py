from Database.DatabaseManager import DataBase
from tinydb import TinyDB, Query
from Utils.Writer import Writer

class AllianceStreamMessage(Writer):

    def __init__(self, client, player, clubLowID, eventType):
        super().__init__(client)
        self.id = 24311
        self.player = player
        self.eventType = eventType
        self.clubLowID = clubLowID

    def encode(self):
        if self.clubLowID != 0:
            # Get the current message count for the club
            DataBase.GetmsgCount(self, self.clubLowID)
            self.writeVint(self.MessageCount)  # Message count
            db = TinyDB('Database/Club/chat.db')
            query = Query()
            data_list = db.search(query.clubID == self.clubLowID)
            if not data_list:
                self.writeVint(0)
                return
            data = data_list[0]
            for i in range(1, self.MessageCount + 1):
                msg_info = data['info'].get(str(i))
                if not msg_info:
                    continue
                self.writeVint(msg_info['Event'])
                self.writeVint(0)
                self.writeVint(msg_info['Tick'])
                self.writeVint(0)
                self.writeVint(msg_info['PlayerID'])
                self.writeString(msg_info['PlayerName'])
                self.writeVint(msg_info['PlayerRole'])
                self.writeVint(0)
                self.writeVint(0)
                if msg_info['Event'] == 4:
                    # For event 4 (Leave Club) write extra details
                    self.writeVint(msg_info['Message'])
                    self.writeVint(1)
                    self.writeVint(0)
                    self.writeVint(msg_info['PlayerID'])
                    self.writeString(msg_info['PlayerName'])
                else:
                    self.writeString(msg_info['Message'])
        else:
            self.writeVint(0)