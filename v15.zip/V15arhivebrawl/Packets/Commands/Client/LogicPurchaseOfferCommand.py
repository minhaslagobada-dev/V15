from Packets.Commands.Server.LogicBoxDataCommand import LogicBoxDataCommand
from Packets.Commands.Server.LogicSkinDataCommand import LogicSkinDataCommand
from Packets.Commands.Server.LogicBrawlerDataCommand import LogicBrawlerDataCommand
from Packets.Messages.Server.OutOfSyncMessage import OutOfSyncMessage
from Database.DatabaseManager import DataBase
from Logic.Shop import Shop
from Packets.Commands.Server.ClaimShopGems import ClaimShopGems

from Utils.Reader import BSMessageReader


class LogicPurchaseOfferCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        # discard unused Vints
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        # the index of the shop offer being purchased
        self.offer_index = self.read_Vint()

    def process(self):
        # Validate that offers exist and index is in range
        if not Shop.offers or self.offer_index < 0 or self.offer_index >= len(Shop.offers):
            OutOfSyncMessage(self.client, self.player, "Invalid offer index or no offers available").send()
            return

        offer = Shop.offers[self.offer_index]
        offer_id = offer.get('ID', -1)
        shop_type = offer.get('ShopType', -1)
        cost = offer.get('Cost', 0)
        brawlerID = offer.get('BrawlerID')
        skinID = offer.get('SkinID')

        # helper to deduct currency and persist; returns False if insufficient funds
        def deduct_and_save(currency_type):
            if currency_type in [0, 2]:  # Gems
                new_amount = self.player.gems - cost
                if new_amount < 0:
                    OutOfSyncMessage(self.client, self.player, "Not enough gems to purchase").send()
                    return False
                self.player.gems = new_amount
                DataBase.replaceValue(self, 'gems', new_amount)
            elif currency_type == 3:  # Star Points
                new_amount = self.player.star_points - cost
                if new_amount < 0:
                    OutOfSyncMessage(self.client, self.player, "Not enough star points to purchase").send()
                    return False
                self.player.star_points = new_amount
                DataBase.replaceValue(self, 'starpoints', new_amount)
            return True

        # Process based on offer ID
        if offer_id in [0, 6, 10, 14]:  # Box offers
            # assign box based on ID
            if offer_id in [0, 6]:
                self.player.box_id = 5
            elif offer_id == 14:
                self.player.box_id = 4
            elif offer_id == 10:
                self.player.box_id = 3

            if deduct_and_save(shop_type):
                # send box data and updated shop offers
                LogicBoxDataCommand(self.client, self.player).send()
                Shop.UpdateOfferData(self, self.offer_index)
                # respond with any claimed gems
                ClaimShopGems(self.client, self.player).send()

        elif offer_id == 4:  # Skin offer
            if deduct_and_save(shop_type):
                LogicSkinDataCommand(self.client, self.player, skinID).send()
                Shop.UpdateOfferData(self, self.offer_index)

        elif offer_id == 3:  # Brawler offer
            if deduct_and_save(shop_type):
                LogicBrawlerDataCommand(self.client, self.player, brawlerID).send()
                Shop.UpdateOfferData(self, self.offer_index)

        else:
            OutOfSyncMessage(
                self.client,
                self.player,
                f'Claiming offer with type {offer_id} is not supported yet'
            ).send()
