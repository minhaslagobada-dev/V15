from random import *
from Database.DatabaseManager import DataBase
from Logic.Boxes import Boxes

from Utils.Writer import Writer


class ClaimShopGems(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24111
        self.player = player
        self.BoxData = Boxes.boxes

    def encode(self):
    	self.writeVint(203) # CommandID
    	self.writeVint(0)   # Unknown
    	self.writeVint(0)   # 1 - specific reward, 0 - regular megabox, 2 and more - blank boxes
    	self.writeVint(10)  # BoxID
        # Box info end

        # Reward start
    	self.writeVint(1) # Reward count aka box count of rewards
    	
    	self.writeVint(60)                           # Reward 1 amount eg powerpoints
    	self.writeScId(16, 20)  # 1: unknown (CsvID) 2: Brawler ID
    	self.writeVint(6)                           # RewardID 
    	self.writeHexa('''00 00 00''')              # Reward end
            # Box end
    	for i in range(13):
    		self.writeVint(0)